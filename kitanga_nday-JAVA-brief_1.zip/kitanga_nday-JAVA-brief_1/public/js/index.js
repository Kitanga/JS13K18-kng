// Create the canvas and context of the differenct layers
let bg_canvas = document.createElement("canvas");
let bg_cx = bg_canvas.getContext("2d");

let shooting_star_canvas = document.createElement("canvas");
let shooting_star_cx = shooting_star_canvas.getContext("2d");

let sun_canvas = document.createElement("canvas");
let sun_cx = sun_canvas.getContext("2d");

let planet_canvas = document.createElement("canvas");
// let planet_cx = planet_canvas.getContext("2d");

let sphere_canvas = document.createElement("canvas");
// let sphere_cx = sphere_canvas.getContext("2d");

let foreground_canvas = document.createElement("canvas");
// foreground_canvas.id = "foreground";
// let foreground_cx = foreground_canvas.getContext("2d");

// Get the canvas dimensions
let width = innerWidth;
let height = innerHeight;

// Set the canvas dimensions
bg_canvas.width = width;
bg_canvas.height = height;

shooting_star_canvas.width = width;
shooting_star_canvas.height = height;

sun_canvas.width = width;
sun_canvas.height = height;

planet_canvas.width = width;
planet_canvas.height = height;

sphere_canvas.width = width;
sphere_canvas.height = height;

foreground_canvas.width = width;
foreground_canvas.height = height;

let halfWidth = roundHalf(width);
let halfHeight = roundHalf(height);

// Color pallete
// Yellow-ish
let sunColor = "#FFA905";
// Pink ish
let spaceColor = "#FF087B";
// orange dark
let planetColor = "#E84304";

let foregroundPurple = "#7B04E8";

let foregroundBlue = "#1F55FF";

let black = "rgb(2, 1, 7)";
let white = "white";

// Sun's radius
let sunRadius = width * 0.177083333;

// Sun's position
let sunX = halfWidth;
let sunY = halfHeight - (height * 0.0467391304);

// The number of stars to place onto the screen
let starCount = round(width * 0.52);

// Shooting object
let star = {
    x: width,
    y: rndInt(0, height * 0.40)
};
let star_trail_offset = 3;

// Use this setInterval to reset the shooting star
let resetShootingStar = setInterval(() => {
    star.x = width;
    star.y = rndInt(0, height * 0.43);
}, 4300);



function init() {
    // Create the space background, draw the stars, sun and planet in that order
    fillSpace(bg_cx);
    addStars(bg_cx);
    addSun(sun_cx);
    appendToBody(bg_canvas, shooting_star_canvas, sun_canvas, sphere_canvas, planet_canvas, foreground_canvas);

    // Set the fill color to white for the shooting star
    shooting_star_cx.fillStyle = 'rgba(255,255,255,1)';

    // Start the shooting star animation
    requestAnimationFrame(animateStar);
}
// Immediately initialize the 
init();

/**
 * Append the canvases to the page
 * 
 * @param  {...HTMLCanvasElement} canvases A list of canvas elements to append to the body
 */
function appendToBody(...canvases) {
    // Append the canvases to the body element
    canvases.forEach(element => {
        document.body.appendChild(element);
    });
}

// Animate the shooting star
function animateStar() {
    // Draw the shooting star
    for (let ix = 7; ix--;) {
        shooting_star_cx.fillRect((star.x -= star_trail_offset), ++star.y, star_trail_offset, star_trail_offset);
    }

    reduceOpacity(shooting_star_cx);
    requestAnimationFrame(animateStar);
}

/**
 * Remove the opacity of a pixel each frame by a certain amount. Used to create the trail effect of the shooting star
 *
 * @param {CanvasRenderingContext2D} cx Context to add the effect to
 * @param {number=} opacity The opacity to reduce by
 */
function reduceOpacity(cx, opacity = 0.052) {
    let imageData = cx.getImageData(0, 0, width, height);
    let data = imageData.data;

    for (let ix = 3, length = data.length; ix < length; ix += 4) {
        if (data[ix]) {
            data[ix] -= Math.round(opacity * 255);
        }
    }
    cx.putImageData(imageData, 0, 0);
}

// Functions used for rendering

/**
 * Add neon themed space background
 * @param {CanvasRenderingContext2D} cx The canvas context to draw to
 */
function fillSpace(cx) {
    // Add some ambience/atmospheric stuff to scene
    let ambienceGrad = cx.createRadialGradient(
        halfWidth,
        height,
        width,
        halfWidth,
        height,
        70
    );

    // Colors stops of the gradient above
    ambienceGrad.addColorStop(0, spaceColor);
    ambienceGrad.addColorStop(1, planetColor);
    // Set as the fill style
    cx.fillStyle = ambienceGrad;
    // Draw the gradient
    cx.fillRect(0, 0, width, height);

    // Reset the color
    resetColor(cx);
}

/**
 * The planet onto the scene
 * @param {CanvasRenderingContext2D} cx The canvas context to draw to
 */
function addPlanet(cx) {
    // Clear the canvas
    let x = halfWidth;
    let y = halfHeight /*  + round(height * .96) */ ;
    let radius = sunRadius /* width > height ? sunRadius * 3 : height * 0.177083333 * 3 */ ;

    cx.fillStyle = planetColor;

    cx.beginPath();
    cx.arc(x, y, radius, 0, Math.PI * 2);
    cx.fill();
    cx.closePath();

    // Add the gradient
    let grad = cx.createRadialGradient(x, y, 0, x, y, radius);
    grad.addColorStop(0.07, 'transparent');
    grad.addColorStop(0.999, sunColor + '61');
    grad.addColorStop(1, sunColor);
    cx.fillStyle = grad;
    // cx.save();
    cx.beginPath();
    cx.arc(x, y, radius, 0, Math.PI * 2);
    cx.fill();
    cx.closePath();

    resetColor(cx);
}

/**
 * Adds a sun onto the canvas
 * @param {CanvasRenderingContext2D} cx The canvas context to draw to
 */
function addSun(cx) {
    // Prep to draw the sun
    cx.fillStyle = sunColor;

    // Save the context's setting so that we can store to the previous clip-path setup of no clip-path
    cx.save();
    cx.beginPath();

    cx.arc(sunX, sunY, sunRadius, 0, Math.PI * 2);

    // Create a mask
    cx.clip();

    // Create our linear gradient
    let grad = cx.createLinearGradient(0, 0, 0, height);
    grad.addColorStop(0, sunColor);
    grad.addColorStop(1, spaceColor /*  + "B3" */ );
    cx.fillStyle = grad;
    cx.fillRect(0, 0, width, height);

    // Restore the previous canvas settings
    cx.restore();
    resetColor(cx);
}

/**
 * Adds stars onto the canvas
 * @param {CanvasRenderingContext2D} cx The canvas context to draw to
 */
function addStars(cx) {
    resetColor(cx);

    for (let ix = starCount; --ix;) {
        if (round(Math.random())) {
            let x = round(Math.random() * width);
            let y = round(Math.random() * height);
            // If the star is outside the sun's radius
            // if (getDistance({x, y}, {x: sunX, y: sunY}) > sunRadius) {
            cx.fillStyle = "rgba(255,255,255," + (1 - (sunRadius / getDistance({
                x,
                y
            }, {
                x: sunX,
                y: sunY
            }))) + ")";
            cx.fillRect(x, y, 1, 1);

            // cx.fillStyle = "rgba(255,255,255,.34)";
            cx.fillStyle = "rgba(255,255,255," + (1 - (sunRadius / getDistance({
                x,
                y
            }, {
                x: sunX,
                y: sunY
            }))) + ")";
            cx.fillRect(x + 1, y, 1, 1);
            cx.fillRect(x, y + 1, 1, 1);
            cx.fillRect(x - 1, y, 1, 1);
            cx.fillRect(x, y - 1, 1, 1);
            resetColor(cx);
            // }
        }
    }
}

// Utility functions

function getDistance(v1, v2) {
    let dist = Math.sqrt(Math.pow(v1.x - v2.x, 2) + Math.pow(v1.y - v2.y, 2));
    // console.log(v1, v2, dist);
    return round(dist);
}

/**
 * Returns a number rounded to the nearest whole number
 * @param {number} num The number to round
 * @returns {number}
 */
function round(num) {
    return Math.round(num);
}

/**
 * Returns half the number as a whole number
 * @param {number} num The number to be operated on
 * @returns {number}
 */
function roundHalf(num) {
    return round(num / 2);
}

/**
 * Resets the color of the canvas context
 * @param {CanvasRenderingContext2D} cx The canvas context to set the reset color to
 */
function resetColor(cx) {
    cx.fillStyle = white;
}

function rndInt(min, max) {
    let _min = typeof min === "undefined" ? 0 : min;
    let _max = typeof max === "undefined" ? 1 : max;

    return round(_min + Math.random() * (_max - _min));
}

/**
 * Wraps 2D points onto a sphere
 * 
 * @param {number} x X position
 * @param {number} y Y position
 * @param {number} w Width of image
 * @param {number} h Height of image
 */
function getSpehericalCoord(x, y, w, h) {
    let newX = Math.sin(x * Math.PI) * Math.cos(y * Math.PI / 2);
    let newY = Math.sin(-y * (Math.PI / 2));
    return {
        x: newX,
        y: newY
    };
}

let music = new Audio();
/**
 * Loads textures
 * 
 * (Borrowed from this site: https://codeincomplete.com/posts/javascript-game-foundations-loading-assets/)
 * 
 * @param {string[]} names An array of the file names that will be downloaded
 * @param {function({})} callback A callback that runs when the loader is done downloading assets
 */
function loadTextures(names, callback) {

    // Name from the names array
    let name = '',
        // Textures will be stored in here by name
        result = {},
        // Number of textures that will have to be downloaded
        count = names.length + 1,
        // The texture loaded
        textureLoader = new THREE.TextureLoader(),
        // Function that runs when the texture has finished loading
        onload = function () {
            if (--count == 0) callback(result);
        };

    for (let ix = 0; ix < names.length; ix++) {
        name = names[ix];

        // Load the image and attach event listener
        result[name.split('.')[0]] = textureLoader.load(`img/${name}`, onload);
    }

    music.oncanplay = onload;
    music.loop = true;
    music.src = 'media/the-end-of-the-world.aac';
}