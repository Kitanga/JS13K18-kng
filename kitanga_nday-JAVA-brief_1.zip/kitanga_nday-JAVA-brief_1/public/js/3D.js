// The planet mesh we will draw onto the scene
let planet = null;

// The vector at which we'll stop the animation
const planet_destination = new THREE.Vector3(0, 0, -halfWidth);
const startVector = new THREE.Vector3(0, -1017, -halfWidth);

let astronautStart = new THREE.Vector3(0, -20, -10);
let astronautEnd = new THREE.Vector3(0, 20, -10);
let astronaut1StartTime = 0;
let astronaut2StartTime = 0;
let astronaut1EndTime = 0;
let astronaut2EndTime = 0;

//
// The time at which we start in ms
let endTime = 0;

// The total amount of ms we'll be running this animation
const totalTime = 25 * 1000;

// The progress made
let progress = 0;

let stopShootingStar = false;

/**
 * Set the 3D scene
 * 
 * @param {HTMLCanvasElement} canvas The element we should draw to
 * @param {[]} textures An array of already loaded textures
 */
function get3DScene(canvas) {
    const width = innerWidth;
    const height = innerHeight;
    const view_angle = 43;
    const aspectRatio = width / height;
    const near = 0.1;
    const far = 1000000;

    // The canvas renderer we use. This allows us to create 3D scenes
    let renderer = new THREE.WebGLRenderer({
        antilias: true,
        alpha: true,
        canvas
    });

    // ...
    let scene = new THREE.Scene();

    let camera = new THREE.PerspectiveCamera(
        view_angle, aspectRatio, near, far
    );

    // Add a light
    const pointLight = new THREE.PointLight(0xffffffff);

    pointLight.position.set(0, 0, 130);

    // Save the references to the scene, renderer, and camera for resize event
    canvas._3 = {
        scene,
        renderer,
        camera
    };

    return {
        renderer,
        scene,
        camera,
        width,
        height
    };
}

function addPlanet(canvas, planetTexture) {
    let {
        scene,
        renderer,
        camera
    } = get3DScene(canvas);
    let material = new THREE.MeshBasicMaterial({
        map: planetTexture
    });
    let geometry = new THREE.SphereGeometry(halfWidth, 32, 32);

    planet_canvas.id = "planet";
    planet = new THREE.Mesh(geometry, material);
    planet.position.z = -7000;

    // Rotate the planet
    planet.rotation.y = THREE.Math.DEG2RAD * -107;
    planet.rotation.x = THREE.Math.DEG2RAD * -20;

    scene.add(planet);
    // console.log('Done and rendered');

    renderer.render(scene, camera);
}

// These are all the sprites we'll add to the foreground layer/canvas
let debris1, debris2, debris3, wrecked1, wrecked2, wrecked3, wrecked4/* , astronaut1, astronaut2 */;

function addForeground(canvas, ...foregroundTextures) {
    let {
        scene,
        renderer,
        camera
    } = get3DScene(canvas);

    const scaleX = 25,
        scaleY = 25,
        scaleZ = 7;

    // Create debris sprites
    const debris1Material = new THREE.SpriteMaterial({
        map: foregroundTextures[0]
    });
    debris1 = new THREE.Sprite(debris1Material);
    debris1.position.set(0, -4.3, -10);
    // console.log(debris1.material.map);
    debris1.scale.set(scaleX, scaleY, scaleZ);

    const debris2Material = new THREE.SpriteMaterial({
        map: foregroundTextures[1]
    });
    debris2 = new THREE.Sprite(debris2Material);
    debris2.position.set(0, -4.3, -10);
    debris2.scale.set(scaleX, scaleY, scaleZ);

    const debris3Material = new THREE.SpriteMaterial({
        map: foregroundTextures[2]
    });
    debris3 = new THREE.Sprite(debris3Material);
    debris3.position.set(0, -4.3, -10);
    debris3.scale.set(scaleX, scaleY, scaleZ);

    // Create wrecked ship sprites
    const wrecked1Material = new THREE.SpriteMaterial({
        map: foregroundTextures[3]
    });
    wrecked1 = new THREE.Sprite(wrecked1Material);
    wrecked1.position.set(-4.3, 1, -7);
    wrecked1.scale.set(4, 3, 0);

    const wrecked2Material = new THREE.SpriteMaterial({
        map: foregroundTextures[4]
    });
    wrecked2 = new THREE.Sprite(wrecked2Material);
    wrecked2.position.set(4.3, 0, -7);
    wrecked2.scale.set(4, 3, 0);

    const wrecked3Material = new THREE.SpriteMaterial({
        map: foregroundTextures[5]
    });
    wrecked3 = new THREE.Sprite(wrecked3Material);
    wrecked3.position.set(-1, -2, -7);
    wrecked3.scale.set(4, 3, 0);
    wrecked3.rotation.y = THREE.Math.DEG2RAD * 34;

    const wrecked4Material = new THREE.SpriteMaterial({
        map: foregroundTextures[6]
    });
    wrecked4 = new THREE.Sprite(wrecked4Material);
    wrecked4.position.set(1.7, -2, -7);
    wrecked4.scale.set(4, 3, 0);

    // Create astronaut sprites
    // const astronaut1Material = new THREE.SpriteMaterial({
    //     map: foregroundTextures[7]
    // });
    // astronaut1 = new THREE.Sprite(astronaut1Material);
    // astronaut1.position = new THREE.Vector3(0, -20, -10);
    // astronaut1.scale.set(4, 4, 0);

    // const astronaut2Material = new THREE.SpriteMaterial({
    //     map: foregroundTextures[8]
    // });
    // astronaut2 = new THREE.Sprite(astronaut2Material);
    // astronaut2.position = new THREE.Vector3(0, -20, -10);
    // astronaut2.scale.set(4, 4, 0);

    // Set rotation direction for wreckage
    wrecked1.material._rotationDir = rndInt(-1, 1);
    wrecked2.material._rotationDir = rndInt(-1, 1);
    wrecked3.material._rotationDir = rndInt(-1, 1);
    wrecked4.material._rotationDir = rndInt(-1, 1);


    // Add sprites to scene
    scene.add(debris1);
    scene.add(debris2);
    scene.add(debris3);
    scene.add(wrecked1);
    scene.add(wrecked2);
    scene.add(wrecked3);
    scene.add(wrecked4);
    // scene.add(astronaut1);
    // scene.add(astronaut2);

    renderer.render(scene, camera);
    window._renderer = renderer;
    window._scene = scene;
    window._camera = camera;
}

function startAnimation(textures) {
    setTimeout(() => {
        // Hide loader
        document.querySelectorAll('#container > *').forEach(element => element.classList.remove('hidden'));

        document.querySelector('.loader').classList.add('hidden');

        endTime = performance.now() + totalTime;

        console.log(textures);

        // Add the planet, debris, bodies, start the loop, and add the class that starts the css animations.
        addPlanet(planet_canvas, textures['earth-2']);
        // addForeground(foreground_canvas, textures['debris2'], textures['debris3'], textures['debris4'], textures['wrecked_1'], textures['wrecked_2'], textures['wrecked_3'], textures['wrecked_4'], textures['astronaut-1'], textures['astronaut-2']);
        music.play();
        document.body.classList.add('loaded');

        // Start the loop
        // loop();
    }, 500);
}

let astronaut1Progress = 0,
    astronaut2Progress = 0;

let firstTime1 = true;
let firstTime2 = true;

function loop() {
    if (!stopShootingStar) {
        requestAnimationFrame(loop);
    }
}

function konamiIsDetected() {
    // Hide all the canvases except for space bg, shooting star, and the sun
    document.querySelectorAll('canvas').forEach(canvas => canvas.hidden = true);
    bg_canvas.hidden = false;
    // shooting_star_canvas.hidden = false;
    clearTimeout(resetShootingStar);
    stopShootingStar = true;
    sun_canvas.hidden = false;
    document.getElementById('container').classList.add('hidden');
    document.getElementById('breaker').classList.remove('hidden');

    startBrickBreaker();
}

function showHomePage() {
    // Hide all the canvases except for space bg, shooting star, and the sun
    document.querySelectorAll('canvas').forEach(canvas => canvas.hidden = false);
    clearTimeout(resetShootingStar);
    document.getElementById('container').classList.remove('hidden');
    document.getElementById('breaker').classList.add('hidden');
}

window.addEventListener('resize', function () {
    width = innerWidth;
    height = innerHeight;
    halfWidth = roundHalf(width);
    halfHeight = roundHalf(height);

    // Set the canvas dimensions
    document.querySelectorAll('canvas').forEach(canvas => {
        canvas.width = width;
        canvas.height = height;

        if (canvas._3) {
            canvas._3.renderer.setSize(width, height);
            canvas._3.renderer.render(canvas._3.scene, canvas._3.camera);
        }
    });
});