// Event listeners
var $ = document.querySelector;

$('#manual').hidden = true;
$('.manual .btn').onclick = () => {
    // 
    $('#manual').hidden = !$('#manual').hidden;
};